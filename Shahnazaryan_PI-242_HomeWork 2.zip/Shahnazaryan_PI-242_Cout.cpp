#include <iostream>
int main() {
	std::cout << 2 + 2 / 5 - 64;
	return 0;
}
